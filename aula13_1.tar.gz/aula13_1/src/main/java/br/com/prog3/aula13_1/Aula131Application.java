package br.com.prog3.aula13_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula131Application {

	public static void main(String[] args) {
		SpringApplication.run(Aula131Application.class, args);
	}

}
