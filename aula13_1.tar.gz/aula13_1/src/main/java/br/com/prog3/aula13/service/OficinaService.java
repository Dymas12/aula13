/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.prog3.aula13.service;

import br.com.prog3.aula13.domain.Cliente;
import br.com.prog3.aula13.domain.Oficina;
import br.com.prog3.aula13.repository.ClienteRepository;
import br.com.prog3.aula13.repository.OficinaRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author lovyca
 */
public class OficinaService {
    
    @Autowired
private OficinaRepository oficinaRepository;
public Oficina save(Oficina oficina) {
return oficinaRepository.save(oficina);
}
public List<Oficina> findAll(){
return (List<Oficina>) oficinaRepository.findAll();
}
public Optional<Oficina> findByCod(Long cod) {
    return oficinaRepository.findByCod(cod);
}
public Oficina update(Oficina Oficina) {
return oficinaRepository.save(Oficina);
}
public void deleteByCod(Long cod) {
oficinaRepository.deleteById(cod);
    
}
    
}
