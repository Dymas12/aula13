/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package br.com.prog3.aula13.repository;

import br.com.prog3.aula13.domain.Cliente;
import br.com.prog3.aula13.domain.Oficina;
import java.util.Optional;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author lovyca
 */
public interface OficinaRepository extends CrudRepository<Oficina, Long>{

    public void deleteByCod(Long cod);

    public Optional<Oficina> findByCod(Long cod);
}
