/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package br.com.prog3.aula13.repository;

import br.com.prog3.aula13.domain.Carro;
import br.com.prog3.aula13.domain.Cliente;
import br.com.prog3.aula13.domain.Oficina;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author lovyca
 */
@Repository
public interface CarroRepository extends JpaRepository<Carro, Long>{
List<Carro> findByCliente(Cliente cliente);
}
    

