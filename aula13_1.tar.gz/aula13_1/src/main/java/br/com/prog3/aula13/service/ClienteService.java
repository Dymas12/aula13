/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.prog3.aula13.service;

import br.com.prog3.aula13.domain.Cliente;
import br.com.prog3.aula13.repository.ClienteRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author lovyca
 */
@Service
public class ClienteService {
@Autowired
private ClienteRepository clienteRepository;
public Cliente save(Cliente cliente) {
return clienteRepository.save(cliente);
}
public List<Cliente> findAll(){
return (List<Cliente>) clienteRepository.findAll();
}
public Optional<Cliente> findByCpf(Long cpf) {
return clienteRepository.findById(cpf);
}
public Cliente update(Cliente Cliente) {
return clienteRepository.save(Cliente);
}
public void deleteByCpf(Long cpf) {
clienteRepository.deleteById(cpf);
    
}
}