/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.prog3.aula13.service;


import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.prog3.aula13.domain.Carro;
import br.com.prog3.aula13.domain.Cliente;
import br.com.prog3.aula13.dto.CarroDTO;
import br.com.prog3.aula13.repository.CarroRepository;

@Service
public class CarroService {
	
	@Autowired
	private CarroRepository carroRepository;
	
	public Carro save(Carro carro) {
		return carroRepository.save(carro);
	}
	
	
	public List<CarroDTO> findAll(){		
		return carroRepository.findAll().stream().map(curso -> new CarroDTO(curso)).collect(Collectors.toList());		
	}
	
	public Optional<Carro> findByCliente(Long cod) {
		return carroRepository.findById(cod);
	}
	
	public Carro update(Carro carro) {
		return carroRepository.save(carro);
	}
	
	public void deleteByCod(Long cod) {
		carroRepository.deleteById(cod);		
	}
	
	public List<Carro> findByCliente(Cliente cliente){
		return (List<Carro>) carroRepository.findByCliente(cliente);
	}

}

  

