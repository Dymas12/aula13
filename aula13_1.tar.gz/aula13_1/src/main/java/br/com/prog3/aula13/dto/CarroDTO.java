/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.prog3.aula13.dto;

import br.com.prog3.aula13.domain.Carro;
import br.com.prog3.aula13.domain.Cliente;
import br.com.prog3.aula13.domain.Oficina;

public class CarroDTO {
private String placa;
    private String cor ;
    private int ano ;
    private int anoModelo;
    private String marca;
    private String modelo;
    private Cliente cliente;
    private Oficina oficina;
public CarroDTO(Carro carro) {
this.placa= carro.getPlaca();
this.cor = carro.getCor();
this.ano = carro.getAno();
this.anoModelo = carro.getAnoModelo();
this.marca = carro.getMarca();
this.modelo = carro.getModelo();
this.cliente = carro.getCliente();
this.oficina = carro.getOficina();

}

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public int getAnoModelo() {
        return anoModelo;
    }

    public void setAnoModelo(int anoModelo) {
        this.anoModelo = anoModelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Oficina getOficina() {
        return oficina;
    }

    public void setOficina(Oficina oficina) {
        this.oficina = oficina;
    }

}

