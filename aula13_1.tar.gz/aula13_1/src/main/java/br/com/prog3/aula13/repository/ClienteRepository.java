/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package br.com.prog3.aula13.repository;

import br.com.prog3.aula13.domain.Cliente;
import java.util.Optional;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author lovyca
 */
@Repository
public interface ClienteRepository extends CrudRepository<Cliente, Long>{

    public void deleteByCpf(Long cpf);

    public Optional<Cliente> findByCpf(Long cpf);
}