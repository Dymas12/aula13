/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.prog3.aula13.resources;

import br.com.prog3.aula13.domain.Carro;
import br.com.prog3.aula13.domain.Cliente;
import br.com.prog3.aula13.domain.Oficina;
import br.com.prog3.aula13.dto.CarroDTO;
import br.com.prog3.aula13.service.CarroService;
import java.util.List;
import java.util.Optional;
import static jdk.nashorn.internal.runtime.Debug.id;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author lovyca
 * 
 */

public class CarroRepository {

    public Carro save(Carro carro) {
       

    
    @RestController
@RequestMapping("/api/v1/cursos")
    
    
 class CarroResource {
        
       @Autowired
	private CarroService carroService;

	@PostMapping
	public Carro save(@RequestBody Carro carro) {
		return carroService.save(carro);
	}

	/*
	 * @GetMapping public ResponseEntity<List<Curso>> findAll() { List<Curso> cursos
	 * = cursoService.findAll(); if (cursos == null || cursos.isEmpty()) { return
	 * new ResponseEntity<List<Curso>>(HttpStatus.NO_CONTENT); } return new
	 * ResponseEntity<List<Curso>>(cursos, HttpStatus.OK); }
	 */
	
	@GetMapping
	public ResponseEntity<List<CarroDTO>> findAll() {
		List<CarroDTO> carros = carroService.findAll();
		if (carros == null || carros.isEmpty()) {
			return new ResponseEntity<List<CarroDTO>>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<List<CarroDTO>>(carros, HttpStatus.OK);
	}

	@GetMapping(path = { "/{cliente}" })
	public ResponseEntity<?> findByCliente(@PathVariable String nome) {
		return carroService.findByCliente(cliente).map(record -> ResponseEntity.ok().body(record))
				.orElse(ResponseEntity.notFound().build());
	}

	@PutMapping(value = "/{cliente}")
	public ResponseEntity<Carro> update(@PathVariable("cliente") String nome, @RequestBody Carro carro) {
		return carroService.findByCliente(cliente).map(record -> {
			record.setcpf(carro.getCpf());
			record.setNome(carro.getNome());
			record.setDataNascimento(carro.getDataNascimento());
			carro updated = carroService.save(record);
			return ResponseEntity.ok().body(updated);
		}).orElse(ResponseEntity.notFound().build());
	}

	@DeleteMapping(path = { "/{cliente}" })
	public ResponseEntity<?> delete(@PathVariable String cliente) {
		return carroService.findByCliente(cliente).map(record -> {
			carroService.deleteByPlaca(placa);
			return ResponseEntity.ok().build();
		}).orElse(ResponseEntity.notFound().build());
	}

	@GetMapping(path = { "cliente/{cliente}" })
	public ResponseEntity<?> findByCliente(@PathVariable("cliente") Cliente cliente) {
		List<carro> carros = carroService.findByCliente(cliente);
		return carros.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(cursos);
	}

}



  

   
