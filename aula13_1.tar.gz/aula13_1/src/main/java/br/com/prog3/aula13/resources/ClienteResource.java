/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.prog3.aula13.resources;

import br.com.prog3.aula13.domain.Cliente;
import br.com.prog3.aula13.service.ClienteService;
import java.util.List;
import static jdk.nashorn.internal.runtime.Debug.id;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author lovyca
 */
@RestController
@RequestMapping("/api/v1/aulas")
public class ClienteResource {
    
 @Autowired
private ClienteService clienteService;
@GetMapping
public ResponseEntity<List<Cliente>> findAll(){
List<Cliente> clientes = clienteService.findAll();
if(clientes == null || clientes.isEmpty()) {
return new
ResponseEntity<List<Cliente>>(HttpStatus.NO_CONTENT);
}
return new ResponseEntity<List<Cliente>>(clientes, HttpStatus.OK);
}
@PostMapping
public Cliente create(@RequestBody Cliente cliente){
return clienteService.save(cliente);
}
@GetMapping(path = {"/{cpf}"})
public ResponseEntity<?> findByCpf(@PathVariable Long cpf){
return clienteService.findByCpf(cpf)
.map(record -> ResponseEntity.ok().body(record))
.orElse(ResponseEntity.notFound().build());
}
@PutMapping(value="/{id}")
public ResponseEntity<Cliente> update(@PathVariable("Cpf") Long cpf,
@RequestBody Cliente cliente) {
    
    

return clienteService.findByCpf(cpf)
.map(record -> {
record.setNome(cliente.getNome());
record.setCpf(cliente.getCpf());
record.setDataNascimento(cliente.getDataNascimento());
Cliente updated = clienteService.save(record);
return ResponseEntity.ok().body(updated);
}).orElse(ResponseEntity.notFound().build());
}
@DeleteMapping(path ={"/{cpf}"})
public ResponseEntity<?> delete(@PathVariable Long cpf) {
return clienteService.findByCpf(cpf)
.map(record -> {
clienteService.deleteByCpf(cpf);
return ResponseEntity.ok().build();
}).orElse(ResponseEntity.notFound().build());
}

}
