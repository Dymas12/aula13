/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.prog3.aula13.domain;

/**
 *
 * @author lovyca
 */
public class Oficina extends Carro{
    private int codigo;
    private String nome;
    private String especialidade;
    private String endereco;
    
    
}
